<?php 
    include("header.php");
?>
<div class="footer1">
    <p>Copyright <i class="far fa-copyright"></i> Project GYM Workout : 2022 All Right Reserved by : <a href="#">Maneesha</a>
</div>
